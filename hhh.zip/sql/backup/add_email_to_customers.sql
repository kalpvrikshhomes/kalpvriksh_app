ALTER TABLE public.customers ADD COLUMN email TEXT;
